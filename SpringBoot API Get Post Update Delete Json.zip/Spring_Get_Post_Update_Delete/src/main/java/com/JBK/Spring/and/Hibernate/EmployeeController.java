package com.JBK.Spring.and.Hibernate;

import java.util.ArrayList;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

	ArrayList<Employee> al = new ArrayList<Employee>();

	public EmployeeController() {
		al.add(new Employee(1, "Gopal", "Pune"));
		al.add(new Employee(2, "Golu", "Mumbai"));
	}

	@RequestMapping("test1")
	ArrayList<Employee> getAllEmployee() {
		return al;
	}

	@RequestMapping("employee/{id}")
	public Employee getEmployee(@PathVariable int id) {

		Employee emp = null;
		for (Employee employee : al) {
			if (employee.id == id) {
				emp = employee;
			}
		}
		return emp;
	}

	@PostMapping("insert")
	ArrayList<Employee> addEmployee(@RequestBody Employee employee) {
		al.add(employee);
		return al;
	}

	@PutMapping("update")
	ArrayList<Employee> updateEmployee(@RequestBody Employee clientEmployee) {
		Employee emp = null;
		for (Employee employee : al) {
			if (employee.id == clientEmployee.id) {
				emp = employee;
				break;
			}
		}
		emp.setName(clientEmployee.name);
		emp.setId(clientEmployee.id);
		emp.setCity(clientEmployee.city);
		return al;
	}

	@DeleteMapping("emp/{id}")
	Employee updateEmployee(@PathVariable int id) {

		Employee emp = null;
		for (Employee employee : al) {
			if (employee.id == id) {
				emp = employee;
				break;
			}

		}
		System.out.println("Remove Success");
		al.remove(emp);
		return emp;

	}

}
