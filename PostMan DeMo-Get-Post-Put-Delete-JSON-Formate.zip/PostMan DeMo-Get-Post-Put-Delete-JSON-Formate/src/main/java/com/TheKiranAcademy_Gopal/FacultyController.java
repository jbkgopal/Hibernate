package com.TheKiranAcademy_Gopal;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FacultyController {

	ArrayList<Faculty> al = new ArrayList<Faculty>();

	public FacultyController() {

		al.add(new Faculty(1001, "JBK_Kiran_Sir", "USA"));
		al.add(new Faculty(1002, "JBK_Gopal_Sir", "California"));
		al.add(new Faculty(1003, "JBK_Amit_Sir", "Paris"));
		al.add(new Faculty(1004, "JBK_Pradip_Sir", "Indonesia"));
		al.add(new Faculty(1005, "JBK_Shivaji_Sir", "Japan"));
		al.add(new Faculty(1006, "JBK_Sagar_Sir", "Canada"));
		al.add(new Faculty(1007, "JBK_Santosh_Sir", "UK"));
		al.add(new Faculty(1008, "JBK_Atul_Sir", "Iran"));
		al.add(new Faculty(1009, "JBK_Sumit_Sir", "Italy"));
		al.add(new Faculty(1010, "JBK_Mayur_Sir", "China"));
		al.add(new Faculty(1011, "JBK_Swanand_Sir", "Kuwait"));
		al.add(new Faculty(1012, "JBK_Amol_Sir", "Malaysia"));
		al.add(new Faculty(1013, "JBK_Ram_Sir", "Mauritania"));
		al.add(new Faculty(1014, "JBK_Guru_Sir", "Malawi"));
		al.add(new Faculty(1015, "JBK_Mangesh_Sir", "New Zealand"));
		al.add(new Faculty(1016, "JBK_Meghana_Madam", "Dubai"));
		al.add(new Faculty(1017, "JBK_Jayshree_Madam", "USA"));
		al.add(new Faculty(1018, "JBK_Ruruja_Madam", "Russia"));
		al.add(new Faculty(1019, "JBK_Ashwini_Madam", "Singapore"));
		al.add(new Faculty(1020, "JBK_Shalaka_Madam", "China"));
	}

	@RequestMapping("showRecord")
	ArrayList<Faculty> getAllFaculty() {
		System.out.println("Multiple Record Show Successfully Done... " + al);
		return al;
	}

	@GetMapping("FacultyShow/{id}")
	public Faculty getFaculty(@PathVariable int id) {

		Faculty faculty = null;
		for (Faculty Faculty : al) {
			if (Faculty.id == id) {
				faculty = Faculty;
			}
		}
		System.out.println("One Record Show Successfully Done... " + faculty);
		return faculty;
	}

	@PostMapping("insertFaculty")
	ArrayList<Faculty> addFaculty(@RequestBody Faculty Faculty) {
		al.add(Faculty);
		System.out.println("Record Inserted Successfully Done... " + al);
		return al;
	}

	@PutMapping("updateFaculty")
	ArrayList<Faculty> updateFaculty(@RequestBody Faculty clientFaculty) {
		Faculty faculty = null;
		for (Faculty Faculty : al) {
			if (Faculty.id == clientFaculty.id) {
				faculty = Faculty;
				break;
			}
		}
		faculty.setName(clientFaculty.name);
		faculty.setId(clientFaculty.id);
		faculty.setCountry(clientFaculty.country);
		System.out.println("Record Updated Successfully Done... " + al);
		return al;
	}

	@DeleteMapping("FacultyDelete/{id}")
	Faculty updateFaculty(@PathVariable int id) {

		Faculty faculty = null;
		for (Faculty Faculty : al) {
			if (Faculty.id == id) {
				faculty = Faculty;
				break;
			}

		}
		al.remove(faculty);
		System.out.println("Record Deleted Successfully Done... " + faculty);
		return faculty;

	}
}
