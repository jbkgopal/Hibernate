package Spring_project.Spring_project_with_DataBase_3;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Controller;
@Entity
@Controller
public class facultyname {

	@Id
	int faculty_id;
	String faculty_name;
	String faculty_city;

	public facultyname() {
		super();
		// TODO Auto-generated constructor stub
	}

	public facultyname(int faculty_id, String faculty_name, String faculty_city) {
		super();
		this.faculty_id = faculty_id;
		this.faculty_name = faculty_name;
		this.faculty_city = faculty_city;
	}

	public int getFaculty_id() {
		return faculty_id;
	}

	public void setFaculty_id(int faculty_id) {
		this.faculty_id = faculty_id;
	}

	public String getFaculty_name() {
		return faculty_name;
	}

	public void setFaculty_name(String faculty_name) {
		this.faculty_name = faculty_name;
	}

	public String getFaculty_city() {
		return faculty_city;
	}

	public void setFaculty_city(String faculty_city) {
		this.faculty_city = faculty_city;
	}

	@Override
	public String toString() {
		return "facultyname [faculty_id=" + faculty_id + ", faculty_name=" + faculty_name + ", faculty_city="
				+ faculty_city + "]";
	}

}
