package com.TheKiranAcademy_Gopal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeMoGetPostPutDeleteJsonFormateApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeMoGetPostPutDeleteJsonFormateApplication.class, args);
		System.err.println("TheKiranAcademy Spring Application is Running...");
	}

}
