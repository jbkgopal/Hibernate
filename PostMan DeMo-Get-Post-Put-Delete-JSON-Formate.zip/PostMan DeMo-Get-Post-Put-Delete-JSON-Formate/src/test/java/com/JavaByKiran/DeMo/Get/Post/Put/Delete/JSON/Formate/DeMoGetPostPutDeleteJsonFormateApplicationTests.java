package com.JavaByKiran.DeMo.Get.Post.Put.Delete.JSON.Formate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeMoGetPostPutDeleteJsonFormateApplicationTests {

	@Test
	void contextLoads() {
	}

}
